#ifndef __CRC32C_H
    #define __CRC32C_H
#include <stdint.h>
uint32_t calc_crc32c (char *data, ssize_t len);

#endif
