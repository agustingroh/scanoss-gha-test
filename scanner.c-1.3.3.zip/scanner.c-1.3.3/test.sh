#!/bin/bash

./scanner . | jq .